# Voikko 1.0.1 corresponding source

The unchanged JavaScript build in vendor/voikko-1.0.1.min.js was published
as npm voikko@1.0.1 (gitHead f86f6117aa6e6d7d49d43de33e1d8380c27982ec).
It contains libvoikko 4.3.2, the JavaScript API and the Finnish morpho dictionary.

This archive contains the preferred source for the library, dictionary and
packaging/build scripts, and the exact dictionary input used for this binary:

* corevoikko-4.3.2.tar.gz: tag rel-libvoikko-4.3.2, including C++, JS API,
  configure scripts, GPL and component licensing notices.
* voikko-fi-snapshot.tar.gz: upstream dictionary source snapshot, with
  Joukahainen vocabulary and generator scripts, published on 2024-06-18.
* dict-morpho.zip: exact dictionary files embedded in the npm WebAssembly.
* npm-source/: unmodified Dockerfile, build.sh, README, package.json and
  TypeScript API source from the npm package. See the upstream build commands.
* dictionary-verification.json: SHA-256 of all three dictionary inputs.

The dictionary files autocorr.vfst, mor.vfst and index.txt were verified
byte-for-byte against the data embedded in the npm package's WebAssembly.
The snapshot index gives version 2.5, build date 2024-06-18 12:31:37 UTC,
and GPL version 2 or later. Upstream lists source commit
fe792042b76605106aaf660e5fe3726b97ff2e12 and vocabulary update 2024-06-18.

## Rebuilding

The upstream npm Dockerfile uses Emscripten SDK 4.0.0 (arm64 image),
libvoikko 4.3.2 and `build.sh embed`, then Terser to minify the result.
Use the supplied archives and dict-morpho.zip in place of the Dockerfile's
network downloads; the public snapshot URLs can change. The unmodified
upstream build recipe is in npm-source/docker/Dockerfile; all library sources
and the modified build.sh used by that recipe are included here.
The GNU build tools, Emscripten SDK and Terser are standard build tools;
install them separately. Bit-identical minification is not promised.

To modify/rebuild the dictionary, unpack voikko-fi-snapshot.tar.gz and
follow its README.md with foma, Python 3, GNU make and native libvoikko's
voikkovfstc installed. Use the original generator options:

    make vvfst VOIKKO_VARIANT=morpho \
      GENLEX_OPTS="--extra-usage=it,science,nature,medicine,education,orgname --style=dialect,old,international,foreign,inappropriate --min-frequency=10"

Replace the files under libvoikko/5/mor-morpho/ before `build.sh embed`.
Do not update vocabulary when reproducing this source snapshot.

The GPL-2.0-or-later dictionary and GPL-compatible library are conveyed
as part of Denantle under GPL-3.0-or-later. Retain original copyright and
alternative-license notices; no rights in upstream work are claimed here.
